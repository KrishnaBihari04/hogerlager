// Dit zijn de belangrijke getallen die we bijhouden in ons spel
let score = 0;
let dice1Value = 1;
let dice2Value = 1;
let nextDice1Value = 1;
let nextDice2Value = 1;
// Deze functie haalt alle belangrijke elementen op van onze webpagina
const scoreElement = document.getElementById('score');
const dice1Element = document.getElementById('dice1');
const dice2Element = document.getElementById('dice2');
const messageElement = document.getElementById('message');
// Deze functie gooit een dobbelsteen (geeft een getal tussen 1 en 6)
function rollDice() {
   return Math.floor(Math.random() * 6) + 1;
}
// Deze functie start het spel opnieuw
function resetGame() {
   // We zetten alle getallen terug naar het begin
   score = 0;
   dice1Value = 1;
   dice2Value = 1;
   // We gooien alvast de dobbelstenen voor de volgende beurt
   nextDice1Value = rollDice();
   nextDice2Value = rollDice();
   // We laten de beginstand zien op het scherm
   updateDisplay();
   messageElement.textContent = 'Welkom! Raad of de volgende worp hoger of lager wordt!';
}
// Deze functie kijkt of de speler goed heeft geraden
function makeGuess(guess) {
   // We rekenen uit wat de huidige en volgende worp samen zijn
   const currentSum = dice1Value + dice2Value;
   const nextSum = nextDice1Value + nextDice2Value;
   // We kijken of het antwoord goed is
   const isHigher = nextSum > currentSum;
   const isCorrect = (guess === 'hoger' && isHigher) || (guess === 'lager' && !isHigher);
   // We laten de nieuwe dobbelstenen zien
   dice1Value = nextDice1Value;
   dice2Value = nextDice2Value;
   // Als het antwoord goed is, krijgt de speler een punt
   if (isCorrect) {
       score++;
       messageElement.textContent = 'Goed geraden! Je krijgt een punt! 🎉';
   } else {
       messageElement.textContent = 'Helaas, dat was niet goed. Probeer het nog eens! 🎲';
   }
   // We maken nieuwe dobbelstenen klaar voor de volgende beurt
   nextDice1Value = rollDice();
   nextDice2Value = rollDice();
   // We laten alles zien op het scherm
   updateDisplay();
}
// Deze functie zorgt ervoor dat alles op het scherm wordt bijgewerkt
function updateDisplay() {
   scoreElement.textContent = score;
   dice1Element.textContent = dice1Value;
   dice2Element.textContent = dice2Value;
}
// Als de pagina wordt geladen, starten we het spel
resetGame();